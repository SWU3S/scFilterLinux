#multiple task:

library(parallel)
library(tidyverse)

file_dir <- 'output/'


# continue the pre-task ---------------------------------------------------



filelist <- dir(path = file_dir ,pattern = '[0-9]+-[0-9]+$' )
file_fasta <- dir(path = file_dir,pattern = '.fasta$')
file_fasta <- str_extract(file_fasta,'[:graph:]+(?=.fasta)')
filelist <- filelist[!filelist %in% file_fasta]
filelist <-paste(file_dir,filelist,sep='')


# task and loading balance ------------------------------------------------


cl <- makeCluster(10) # at lest 3GB for single thread



cat('running...\n')
parLapplyLB(cl = cl ,filelist,
          function(i)
          {

            scfilterLinux::scfilter_main(inputfile = i,outputfile = i,
                                         blastn_db = 'database/iwgsc_refseqv2.0_chr5A.fa',
                                         blastn_para = ' -evalue 1e-5  -word_size 11  -outfmt 6')
          }
)
cat('finish...\n')
stopCluster(cl)
"
